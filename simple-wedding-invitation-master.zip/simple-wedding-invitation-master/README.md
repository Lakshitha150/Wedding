# Singple Wedding Invitation Landing Page 


# Section/Feature
- Main Info
- Countdown to D-Day
- Time and Place Info
- Add to Calendar Button (Google Calendar)
- Map Direction Button (Google Map)
- Send Message Button (Whatssapp API)

# Stack
- Netlify (https://netlify.com)

- Bulma CSS (https://bulma.io)

# Info
- Preview live at: [https://simple-wedding-invitation.dae.ng/] (https://simple-wedding-invitation.dae.ng/)
- Or check demo at: [https://simple-wedding-invitation.netlify.app/](https://simple-wedding-invitation.netlify.app/)

# Fonts
- Rouge Script (Google Font)
- Raleway (Google Font)


# Credits
- Floral vector created by BiZkettE1 - www.freepik.com (https://www.freepik.com/free-photos-vectors/background)
- Photos from unsplash.com (https://www.unsplash.com)
